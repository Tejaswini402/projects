<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" media="screen and (max-width:800px" href="tablet.css">
    <link rel="stylesheet" media="screen and (max-width:530px" href="phone.css">
</head>

<body>
    <nav class="navbar">
        <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About Me</a></li>
            <li><a href="#portfolio">Portfolio</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#contact">Contact Me</a></li>
        </ul>
    </nav>
    <section id="home">
        <div class="main">
            <h1 class="headings">I AM <br> BILLAKURTHI TEJASWINI</h1>
            <button class="btn">
                Hire Me
            </button>
        </div>
    </section>
    <section id="about">
        <h1 class="headings">ABOUT ME</h1>
        <div id="pic">
            <img src="2.jpg" alt="">
            <div id="intro">
                <h2>TEJASWINI</h2>
                <p>To secure a challenging career with a stimulating environment where I can apply may
                    innovative ideas and knowledge for growth of the organization. Looking for an
                    internship position to learn and acquire extensive knowledge and experience while
                    effectively performing my duties.</p>
            </div>
        </div>
    </section>
    <section id="portfolio">
        <h1 class="headings">PORTFOLIO</h1>
        <div class="gallery">
           <a href="https://www.google.com"> <img src="1.jpg" alt=""></a>
            <a href="https://www.google.com"><img src="3.jpg" alt=""></a>
            <a href="https://www.google.com"><img src="4.png" alt=""></a>
            <a href="https://www.google.com"><img src="5.jpg" alt=""></a>
            <a href="https://www.google.com"><img src="6.jpg" alt=""></a>
            <a href="https://www.google.com"><img src="7.jpg" alt=""></a>
        </div>

    </section>
    <section id="services">
        <h1 class="headings">SERVICES</h1>
        <div class="row">
            <div class="box">
                <img src="10.jpg" alt="">
                <h1 class="headings">Web Developer</h1>
                <p>This is a beginner-level project that is great for honing your JavaScript skills. In this project, you will design a website’s login authentication bar – where users enter their email ID/username and password to log in to the site. Since almost every website now comes with a login authentication feature, learning this skill will come in handy in your future web projects and applications.</p>
            </div>
            <div class="box">
                <img src="11.png" alt="">
                <h1 class="headings">UX/UI <br> Designs</h1>
                <p>UX/UI Designer resume should prove that you can solve problems, design solutions and execute on them to make a positive impact for a business. Not only can you design functional web projects, but you can test those designs and study the user experience. All that, while being an excellent team member to work with.</p>
            </div>
            <div class="box">
                <img src="12.png" alt="">
                <h1 class="headings">PHP Developer</h1>
                <p>Implement code based on project specifications.
Create new tables within MySQL.
Test and document code.</p>
            </div>
        </div>
    </section>
    <section id="contact">
        <h1 class="headings">CONTACT</h1>
        <form action="form.php" method="post" class="form">
            <input type="text" name="name" class="input" required="Enter Your Name" placeholder="Enter Your Name">
            <input type="email" name="email" class="input" required="Enter Your Email" placeholder="Enter Your Email">
            <input type="text" name="mobile" class="input" required="Enter Your Mobile Number" placeholder="Enter Your Mobile Number">
            <textarea name="msg" id="m" cols="30" rows="10" required="Enter Your Message" placeholder="Enter Your Message"></textarea>
            <input type="submit" name="s" value="SEND" id="send" class="btn">
        </form>
    </section>
</body>

</html>