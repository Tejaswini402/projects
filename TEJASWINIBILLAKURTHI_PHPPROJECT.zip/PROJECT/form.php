<?php 
//mysqli_connect("localhost","root","");
//mysql_select_db("t4");
//connection to mysql
$conn=mysqli_connect("localhost","root","","t4");
if(!$conn)
{
   die("Connection Failed".mysql_connect_error());
}
if(isset($_POST['s']))
{
    $name=$_POST['name'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];
    $msg=$_POST['msg'];

    $sql_query="INSERT INTO send(name,email,mobile,msg)
VALUES('$name','$email','$mobile','$msg')";
 if( mysqli_query($conn,$sql_query) )
 {
   header("Location: index.php");
 }
 else
 {
 echo ("Error Creating Database".mysqli_error($conn));
 }
 mysqli_close($conn);
}
?>